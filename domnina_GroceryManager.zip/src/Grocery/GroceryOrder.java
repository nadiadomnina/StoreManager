package Grocery;

import java.util.ArrayList;

public class GroceryOrder<T> extends ArrayList<GroceryItem> {

	private static final long serialVersionUID = 1L;

}
